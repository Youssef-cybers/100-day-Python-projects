import requests
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart

# Set up email and API credentials (Replace with your own values)
my_email = "my_email"
recipient_email = "recipient_email"
password = "Your own App Password"

# Define stock and company information
STOCK_NAME = "TSLA"
COMPANY_NAME = "Tesla Inc"

# Define API endpoints and keys
STOCK_ENDPOINT = "https://www.alphavantage.co/query"
NEWS_ENDPOINT = "https://newsapi.org/v2/everything"
STOCK_API_KEY = "Your own stock API-key"
NEWS_API_KEY = "Your own news API-key"

# Set parameters for stock API request
stock_params = {
    "function": "TIME_SERIES_DAILY",
    "symbol": STOCK_NAME,
    "apikey": STOCK_API_KEY,
}

# Get stock data from Alpha Vantage API
stock_response = requests.get(url=STOCK_ENDPOINT, params=stock_params)
stock_response.raise_for_status()
stock_data = stock_response.json()

# Extract yesterday and day-before closing prices from stock data
yesterday_closing_price = [float(value['4. close']) for key1, value in stock_data['Time Series (Daily)'].items()][1]
day_before_closing_price = [float(value['4. close']) for key2, value in stock_data['Time Series (Daily)'].items()][2]

# Calculate the percentage difference in closing prices
price_difference = ((yesterday_closing_price - day_before_closing_price) / day_before_closing_price) * 100

# Determine if the stock is up or down
up_down = "Up" if price_difference > 0 else "Down"
print(price_difference)

# Check if the price difference is significant (greater than or equal to 1%)
if price_difference >= 1:
    # Set up parameters for news API request
    news_params = {
        "apiKey": NEWS_API_KEY,
        "qInTitle": COMPANY_NAME,
    }

    # Get news data from News API
    news_response = requests.get(url=NEWS_ENDPOINT, params=news_params)
    news_response.raise_for_status()
    news_data = news_response.json()

    # Extract the first three articles
    articles = news_data["articles"]
    three_articles = articles[:3]

    # Format the articles for email
    formatted_articles = [(f"{STOCK_NAME}: {up_down}{price_difference}%\nHeadline: {article['title']}. \n"
                           f"Brief: {article['description']}") for article in three_articles]
    print(formatted_articles)

    # Email server setup (for Gmail)
    smtp_server = "smtp.gmail.com"
    smtp_port = 587

    try:
        # Log in to the email server
        with smtplib.SMTP(smtp_server, smtp_port) as connection:
            connection.starttls()
            connection.login(user=my_email, password=password)

            # Send an email for each formatted article
            for formatted_article in formatted_articles:
                # Create the email message
                subject = f"Stock News - {COMPANY_NAME}"
                body = formatted_article
                message = MIMEMultipart()
                message["From"] = my_email
                message["To"] = recipient_email
                message["Subject"] = subject
                message.attach(MIMEText(body, "plain"))

                # Send the email
                connection.sendmail(from_addr=my_email, to_addrs=recipient_email, msg=message.as_string())

        print("Emails sent successfully!")

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        print("Emails could not be sent.")

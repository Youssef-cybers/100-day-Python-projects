import smtplib
import requests

# Define email addresses, password, and API key
sending_address = "sending_address"
receiving_address = "receiving_address"
password = "Your own App Password"
api_key = "Your own API-Key"

# Set latitude and longitude for weather query (Astoria, Queens, NYC, New York, USA, North America)
MY_LAT = 40.766891
MY_LON = -73.921387

# Set parameters for OpenWeatherMap API request
params = {
    "lat": MY_LAT,
    "lon": MY_LON,
    "appid": api_key,
    "cnt": 4,
}

# Make API request to OpenWeatherMap
response = requests.get(url="https://api.openweathermap.org/data/2.5/forecast", params=params)
response.raise_for_status()
weather_data = response.json()

# Check if it will rain based on weather conditions
will_rain = False
for hour_data in weather_data["list"]:
    condition_code = hour_data["weather"][0]["id"]
    if int(condition_code) < 700:
        will_rain = True

# If rain is predicted, send email notification
if will_rain:
    with smtplib.SMTP("smtp.gmail.com") as connection:
        connection.starttls()
        connection.login(sending_address, password)
        connection.sendmail(
            from_addr=sending_address,
            to_addrs=receiving_address,
            msg=f"Subject: Watch out, partner!\n\nYou need an Umbrella (ella ella eh eh)! ☔"
        )

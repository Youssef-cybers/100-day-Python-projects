from turtle import Turtle
STARTING_POSITION = (0, -260)
MOVE_DISTANCE = 10
FINISH_LINE_Y = 280


class Player(Turtle):
    # Initializing player default settings
    def __init__(self, position):
        super().__init__()
        self.shape("turtle")
        self.setheading(90)
        self.penup()
        self.goto(position)

    # Meant to go back to player's initialized values when the method is being called
    def reset_player(self):
        self.shape("turtle")
        self.setheading(90)
        self.penup()
        self.goto(STARTING_POSITION)

    # Changes the Y-coördinate so that the player can move up
    def move(self):
        new_y = self.ycor() + 10
        self.goto(self.xcor(), new_y)


from turtle import Turtle
BOARD_POSITION = (-200, 245)
FONT = ("Courier", 18, "normal")


class Levels(Turtle):
    # Initializes the default settings of the level board
    def __init__(self):
        super().__init__()
        self.penup()
        self.hideturtle()
        self.level = 0
        self.update_level_board()

    # Showcases the new level
    def level_passed(self):
        self.level += 1
        self.update_level_board()

    # Updates the level board
    def update_level_board(self):
        self.clear()
        self.goto(BOARD_POSITION)
        self.write(f"Level: {self.level}", align='center', font=FONT)

    # Showcases "Game Over on screen"
    def game_over(self):
        self.clear()
        self.goto(0, 50)
        self.write("Game Over", align="center", font=FONT)


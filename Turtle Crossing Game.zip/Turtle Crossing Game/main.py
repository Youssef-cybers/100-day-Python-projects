from turtle import Screen
from levels import Levels
from player import Player
from cars import RandomCars
import time
STARTING_POSITION = (0, -260)

# Setting up screen default settings
screen = Screen()
screen.setup(width=600, height=600)
screen.tracer(0)


# Declares turtle object
turtle = Player(STARTING_POSITION)


# Declares level board object
level_board = Levels()


# Declares cars object
cars = RandomCars()


# Makes the player move up with the 'up' key.
screen.listen()
screen.onkey(turtle.move, "Up")


# Refreshes the game screen with every 0.1 sec delay
game_is_on = True
while game_is_on:
    time.sleep(cars.velocity)
    screen.update()

    # Makes sure that with every refresh a car will be spawned
    cars.create_cars()

    # Makes sure that with every refresh the cars will move
    cars.move_cars()

    # Detect collision with ceiling of window
    if turtle.ycor() > 280:
        turtle.reset_player()
        level_board.level_passed()
        cars.speed_up()

    # Detect collision with cars
    for car in cars.all_cars:
        if car.distance(turtle) < 20:
            game_is_on = False
            level_board.game_over()

# Makes sure the window doesn't disappear
screen.exitonclick()

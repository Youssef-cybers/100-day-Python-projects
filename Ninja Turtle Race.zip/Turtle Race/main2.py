import turtle
from turtle import Turtle, Screen
import random

is_race_on = False

screen = Screen()
screen.setup(width=500, height=400)

user_bet = screen.textinput(title="Make your bet", prompt="Which turtle will win the race (leo/raph/donny/mickey)?: ")
print(user_bet)
colors = {"leo": "RoyalBlue3",
          "raph": "red2",
          "donny": "DarkOrchid",
          "mickey": "OrangeRed"
}
y_positions = [-60, -20, 20, 60]

turtles = []

for turtle_index, turtle_name in enumerate(colors.keys()):
    ninja = Turtle("turtle")
    ninja.penup()
    ninja.goto(x=-230, y=y_positions[turtle_index])
    ninja.color(colors[turtle_name])
    turtles.append(ninja)

if user_bet:
    is_race_on = True

winning_turtle_index = None  # Variable to store the winning turtle's index

while is_race_on:
    for i, turtle in enumerate(turtles):
        rand_distance = random.randint(0, 10)
        turtle.forward(rand_distance)

        if turtle.xcor() >= 230:
            winning_turtle_index = i
            is_race_on = False  # Race is over

# Check if the user's bet matches the winning turtle and update its color
if winning_turtle_index is not None and user_bet.lower() == list(colors.keys())[winning_turtle_index]:
    turtles[winning_turtle_index].color("green")

screen.exitonclick()

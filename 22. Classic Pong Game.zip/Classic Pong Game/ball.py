from turtle import Turtle


class Ball(Turtle):
    # Initializes the default settings of the ball
    def __init__(self):
        super().__init__()
        self.penup()
        self.color("white")
        self.shape("circle")
        self.x_move = 10
        self.y_move = 10
        self.velocity = 0.1

    # Makes the ball increase the x- and y-coördinates so the ball starts moving into the upper right corner
    def move(self):
        new_x = self.xcor() + self.x_move
        new_y = self.ycor() + self.y_move
        self.goto(new_x, new_y)

    # Makes the y-coördinate change when ball bounces
    def bounce_y(self):
        self.y_move *= -1

    # Makes the x-coördinate and velocity of the ball change when ball bounces
    def bounce_x(self):
        self.x_move *= -1
        self.velocity *= 0.7

    # Resets the position and the velocity and reverses x-axis of the ball if it hit the wall
    def reset_position(self):
        self.goto(0, 0)
        self.velocity = 0.1
        self.bounce_x()

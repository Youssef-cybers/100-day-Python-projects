import requests
from datetime import datetime

# Declaring the constants
USERNAME = "yourownusername"
TOKEN = "randomlygeneratedtoken"

# Declaring the endpoint and the user parameters
pixela_endpoint = "https://pixe.la/v1/users"
user_params = {
    "token": TOKEN,
    "username": USERNAME,
    "agreeTermsOfService": "yes",
    "notMinor": "yes",
}

# Posting the user parameters to the pixela endpoint to create the account and checking if it was successful or not
response = requests.post(url=pixela_endpoint, json=user_params)
print(response.text)

# Declaring the endpoint for creating a graph and the graph parameters
graph_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs"
# These can be whatever you want
graph_params = {
    "id": "graph1",
    "name": "Daily Coding Tracker",
    "unit": "days",
    "type": "int",
    "color": "shibafu",
}

headers = {
    "X-USER-TOKEN": TOKEN,
}

# Posting the data to the pixela endpoint to create the graph and checking if it was successful or not
response = requests.post(url=graph_endpoint, json=graph_params, headers=headers)
print(response.text)

today = datetime.now()

# Declaring the endpoint for adding a pixel to the graph and the pixel data
pixel_creation_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/graph1"
pixel_data = {
    "date": today.strftime("%Y%m%d"),
    "quantity": "1",
}

# Posting the data to the pixela endpoint to add a pixel to the graph and checking if it was successful or not
response = requests.post(url=pixel_creation_endpoint, json=pixel_data, headers=headers)
print(response.text)

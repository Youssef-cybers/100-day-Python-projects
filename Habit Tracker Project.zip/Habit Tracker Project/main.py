# Import necessary libraries
import requests
from datetime import datetime

# Set up constants for Pixela API
USERNAME = "your_username"
TOKEN = "your_token"
GRAPH_ID = "your_graph"

# Define the endpoint for Pixela user creation
pixela_endpoint = "https://pixe.la/v1/users"

# Set up parameters for creating a new Pixela user
user_params = {
    "token": TOKEN,
    "username": USERNAME,
    "agreeTermsOfService": "yes",
    "notMinor": "yes",
}

# Define the endpoint for creating a new graph on Pixela
graph_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs"
graph_config = {
    "id": GRAPH_ID,
    "name": "Name Graph",
    "unit": "Unit",
    "type": "int",
    "color": "shibafu"
}

# Set up headers for authentication
headers = {
    "X-USER-TOKEN": TOKEN,
}

# Uncomment the next two lines to create a new graph on Pixela
# response = requests.post(url=graph_endpoint, json=graph_config, headers=headers)

# Define today's date for Pixel creation (you can insert your own current date)
today = datetime(year=2023, month=11, day=27)

# Define the endpoint for creating a new pixel on Pixela
pixel_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}"
pixel_config = {
    "date": today.strftime("%Y%m%d"),
    "quantity": "10",
}

# Uncomment the next two lines to create a new pixel on Pixela
# response = requests.post(url=pixel_endpoint, json=pixel_config, headers=headers)
# print(response.text)

# Define the endpoint for updating an existing pixel on Pixela
update_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}/{today.strftime('%Y%m%d')}"
new_pixel_data = {
    "quantity": "14"
}

# Uncomment the next two lines to update an existing pixel on Pixela
# response = requests.put(url=update_endpoint, json=new_pixel_data, headers=headers)
# print(response.text)

# Define the endpoint for deleting an existing pixel on Pixela
delete_endpoint = f"{pixela_endpoint}/{USERNAME}/graphs/{GRAPH_ID}/{today.strftime('%Y%m%d')}"

# Uncomment the next two lines to delete an existing pixel on Pixela
# response = requests.put(url=delete_endpoint, headers=headers)
# print(response.text)

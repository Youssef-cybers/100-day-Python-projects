from tkinter import *


def button_clicked():
    miles = float(user_input.get())
    convert = miles * 1.609344
    km.config(text=convert)


window = Tk()
window.title("Mile to Km Converter")
window.config(padx=20, pady=20)


miles_label = Label(text="Miles")
miles_label.grid(column=2, row=0)


is_equal_label = Label(text="is equal to")
is_equal_label.grid(column=0, row=1)


km = Label(text="0")
km.grid(column=1, row=1)


km_label = Label(text="Km")
km_label.grid(column=2, row=1)


cal_button = Button(text="Calculate", command=button_clicked)
cal_button.grid(column=1, row=2)


user_input = Entry(width=7)
user_input.grid(column=1, row=0)


window.mainloop()

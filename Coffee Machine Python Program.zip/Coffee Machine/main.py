from data import MENU
from data import resources

water_amount = resources['water']
milk_amount = resources['milk']
coffee_amount = resources['coffee']

money_amount = 0
run = 1
turn_off = False

while turn_off is False:
    users_order = input("What would you like? (espresso/latte/cappuccino): ")
    if users_order == "espresso":
        water_amount -= 50
        coffee_amount -= 18
        if water_amount <= 0:
            print("Sorry, but we're out of water.")
        if milk_amount <= 0:
            print("Sorry, but we're out of milk.")
        if coffee_amount <= 0:
            print("Sorry, but we're out of coffee. (I know, it sounds stupid)")
        price = 1.5
        quarter_amount = float(input("How many quarters: ")) * 0.25
        dimes_amount = float(input("How many dimes: ")) * 0.10
        nickels_amount = float(input("How many nickels: ")) * 0.05
        pennies_amount = float(input("How many pennies: ")) * 0.01
        money_amount = (quarter_amount + dimes_amount + nickels_amount + pennies_amount)
        change = price - (quarter_amount + dimes_amount + nickels_amount + pennies_amount)
        if change < 0:
            print("You have insufficient funds.")
        else:
            print(f"Your change is {change}")
    elif users_order == "latte":
        water_amount -= 200
        milk_amount -= 150
        coffee_amount -= 24
        if water_amount <= 0:
            print("Sorry, but we're out of water.")
        if milk_amount <= 0:
            print("Sorry, but we're out of milk.")
        if coffee_amount <= 0:
            print("Sorry, but we're out of coffee. (I know, it sounds stupid)")
        price = 2.5
        quarter_amount = float(input("How many quarters: ")) * 0.25
        dimes_amount = float(input("How many dimes: ")) * 0.10
        nickels_amount = float(input("How many nickels: ")) * 0.05
        pennies_amount = float(input("How many pennies: ")) * 0.01
        money_amount = (quarter_amount + dimes_amount + nickels_amount + pennies_amount)
        change = price - (quarter_amount + dimes_amount + nickels_amount + pennies_amount)
        if change < 0:
            print("You have insufficient funds.")
        else:
            print(f"Your change is {change}")
    elif users_order == "cappuccino":
        water_amount -= 250
        milk_amount -= 100
        coffee_amount -= 24
        if water_amount <= 0:
            print("Sorry, but we're out of water.")
        if milk_amount <= 0:
            print("Sorry, but we're out of milk.")
        if coffee_amount <= 0:
            print("Sorry, but we're out of coffee. (I know, it sounds stupid)")
        price = 3.0
        quarter_amount = float(input("How many quarters: ")) * 0.25
        dimes_amount = float(input("How many dimes: ")) * 0.10
        nickels_amount = float(input("How many nickels: ")) * 0.05
        pennies_amount = float(input("How many pennies: ")) * 0.01
        money_amount = (quarter_amount + dimes_amount + nickels_amount + pennies_amount)
        change = price - (quarter_amount + dimes_amount + nickels_amount + pennies_amount)
        if change < 0:
            print("You have insufficient funds.")
        else:
            print(f"Your change is {change}")
    elif users_order == "report":
        print(f"Water: {water_amount}")
        print(f"Milk: {milk_amount}")
        print(f"Coffee: {coffee_amount}")
        print(f"Money: ${money_amount}")
    elif users_order == "off":
        run = 0

    if run == 0:
        turn_off = False
# espresso_water = MENU['espresso']['ingredients']['water']
# print(espresso_water)

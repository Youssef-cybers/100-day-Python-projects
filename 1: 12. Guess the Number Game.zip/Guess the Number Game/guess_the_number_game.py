from art import logo
from replit import clear
import random

print(logo)
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
           11, 12, 13, 14, 15, 16, 17, 18, 19, 20,
           21, 22, 23, 24, 25, 26, 27, 28, 29, 30,
           31, 32, 33, 34, 35, 36, 37, 38, 39, 40,
           41, 42, 43, 44, 45, 46, 47, 48, 49, 50,
           51, 52, 53, 54, 55, 56, 57, 58, 59, 60,
           61, 62, 63, 64, 65, 66, 67, 68, 69, 70,
           71, 72, 73, 74, 75, 76, 77, 78, 79, 80,
           81, 82, 83, 84, 85, 86, 87, 88, 89, 90,
           91, 92, 93, 94, 95, 96, 97, 98, 99, 100]
random_numbers = random.choice(numbers)

def play_game():
  guesses = 0
  print("Welcome to the Word Guessing Game.\n I'm thinking of a number between 1 and 100.")
  choose_difficulty = input("Choose a difficulty. Type 'easy' or 'hard'. ")
  if choose_difficulty == "easy":
    guesses += 10
  elif choose_difficulty == "hard":
    guesses += 5


  while guesses >= 1:
    users_choice = int(input("Make a guess: "))
    if users_choice == random_numbers:
      clear()
      print(f"{random_numbers} is the correct answer")
      print("That's correct! Great job.")
      play_again = input("Would you like to play another game? Type 'y' or 'n': ")
      if play_again == 'n':
        return 
        # guesses = 0
        #clear()
      elif play_again == 'y':
        clear()
        play_game()
    elif users_choice > random_numbers:
      print("Too high. Try again")
      guesses -= 1
    elif users_choice < random_numbers:
      print("Too low. Try again.")
      guesses -= 1

  if guesses == 0:
    clear()
    print(f"Seems like you're out of guesses.\n The correct number was {random_numbers}")
    play_again = input("Would you like to try again? Type 'y' or 'n'.")
    if play_again == 'n':
      print("Okay, bye")
      guesses = 0
    elif play_again == 'y':
      clear()
      play_game()
      
play_game()